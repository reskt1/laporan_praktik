<?php $__env->startSection('title', 'Data Skema'); ?>

<?php $__env->startSection('content'); ?>

<h1>Data Skema</h1>



<?php if(session('success')): ?>

    <div class="alert-success">
        <?php echo e(session('success')); ?>

    </div>

<?php endif; ?>




<div class="page-header">

    <div>
        <h2>Daftar Skema Sertifikasi</h2>

        <p>
            Data skema sertifikasi yang tersedia.
        </p>
    </div>

    <a
        href="<?php echo e(route('skema.create')); ?>"
        class="button"
    >
        + Tambah Skema
    </a>

</div>




<div class="table-container">

    <table>

        <thead>

            <tr>
                <th>No</th>
                <th>Nama Skema</th>
                <th>Kode Skema</th>
                <th>Jumlah Peserta</th>
                <th>Aksi</th>
            </tr>

        </thead>

        <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $skemas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skema): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <tr>

                    <td>
                        <?php echo e($loop->iteration); ?>

                    </td>

                    <td>
                        <?php echo e($skema->nama_skema); ?>

                    </td>

                    <td>
                        <?php echo e($skema->kode_skema); ?>

                    </td>

                    <td>
                        <?php echo e($skema->pesertas->count()); ?> peserta
                    </td>

                    <td class="actions">

                        <a
                            href="<?php echo e(route('skema.show', $skema)); ?>"
                            class="button detail"
                        >
                            Detail
                        </a>

                        <a
                            href="<?php echo e(route('skema.edit', $skema)); ?>"
                            class="button edit"
                        >
                            Edit
                        </a>

                        <form
                            action="<?php echo e(route('skema.destroy', $skema)); ?>"
                            method="POST"
                            style="display: inline;"
                        >

                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <button
                                type="submit"
                                class="button delete"
                                onclick="return confirm('Yakin ingin menghapus skema ini?')"
                            >
                                Hapus
                            </button>

                        </form>

                    </td>

                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <tr>

                    <td colspan="5" class="empty">
                        Belum ada data skema.
                    </td>

                </tr>

            <?php endif; ?>

        </tbody>

    </table>

</div>




<style>

    .alert-success {
        background-color: #d4edda;
        color: #155724;

        padding: 12px 15px;

        border-radius: 6px;

        margin-bottom: 20px;
    }

    .page-header {
        background-color: white;

        padding: 20px 25px;

        border-radius: 10px;

        margin-bottom: 20px;

        display: flex;

        justify-content: space-between;

        align-items: center;

        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
    }

    .page-header h2 {
        margin: 0 0 5px 0;
    }

    .page-header p {
        margin: 0;

        color: #666;
    }

    .button {
        display: inline-block;

        padding: 8px 12px;

        border: none;

        border-radius: 5px;

        text-decoration: none;

        cursor: pointer;

        font-size: 14px;

        background-color: #333;

        color: white;
    }

    .button:hover {
        opacity: 0.8;
    }

    .detail {
        background-color: #ffa601;
    }

    .edit {
        background-color: #01ccff;
    }

    .delete {
        background-color:   #ff0101;
    }

    .table-container {
        background-color: white;

        padding: 20px;

        border-radius: 10px;

        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);

        overflow-x: auto;
    }

    table {
        width: 100%;

        border-collapse: collapse;
    }

    th,
    td {
        padding: 12px;

        border-bottom: 1px solid #ddd;

        text-align: left;
    }

    th {
        background-color: #2b5cb8;

        color: white;
    }

    tr:hover {
        background-color: #6cdff3;
    }

    .actions {
        white-space: nowrap;
    }

    .empty {
        text-align: center;

        color: #777;

        padding: 30px;
    }

    @media (max-width: 700px) {

        .page-header {
            flex-direction: column;

            align-items: flex-start;

            gap: 15px;
        }

    }

</style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\skema_sertifikasi_resky\resources\views/skema/index.blade.php ENDPATH**/ ?>