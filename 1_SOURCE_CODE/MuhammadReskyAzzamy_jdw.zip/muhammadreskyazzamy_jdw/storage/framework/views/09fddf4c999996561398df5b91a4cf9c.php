
<!DOCTYPE html>
<html lang="id">
<head>


    <title>Silahkan login</title>

    <style>
        body {
            font-family: Arial, sans-serif;
           background:
                radial-gradient(circle at 50% 40%,
                #ffffff 0%, #f4f8fb 65%, #e9f1f7 100%);
            margin: 0;
            min-height: 100vh;

            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-box {
            background-color: white;
            width: 350px;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .login-box h1 {
            text-align: center;
            margin-bottom: 10px;
        }

        .login-box p {
            text-align: center;
            color: #666;
            margin-bottom: 25px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .login-button {
            width: 100%;
            padding: 10px;
            background-color: #6597b8;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .login-button:hover {
            background-color: #555;
        }

        .error {
            background-color: #ffe5e5;
            color: #b00000;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
        }
        a{
            display: block;
            text-align: center;
            margin-top: 15px;
            color: #008bfc;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        h1{
            cursor: default;
        }
        p{
            cursor: default;
        }
        .auth-links {
            display: flex;
            justify-content: space-between;
            margin-top: 15px;
            font-size: 14px;
        }
    </style>
</head>

<body>

    <div class="login-box">

        <h1>Login</h1>

        <p>Silahkan Login Akun Anda</p>

        <?php if($errors->any()): ?>
            <div class="error">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('login.process')); ?>" method="POST">

            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="email">Email</label>

                <input
                    type="email"
                    id="email"
                    name="email"
                    value="<?php echo e(old('email')); ?>"
                    placeholder="Masukkan email"
                    required
                >
            </div>

            <div class="form-group">
                <label for="password">Password</label>

                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Masukkan password"
                    required
                >
            </div>

            <button type="submit" class="login-button">
                Login
            </button>

            <div class="auth-links">
                <a href="/">← Kembali</a>
                <a href="<?php echo e(route('register')); ?>">Belum punya akun?</a>
            </div>
            <br>
            <?php if(session('success')): ?>
                <div style="background-color: #d4edda; color: #155724; padding: 10px; margin-bottom: 15px; border-radius: 5px; text-align: center; font-size: 14px;">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
        </form>

    </div>

</body>
</html>

<?php /**PATH F:\muhammadreskyazzamy_jdw\resources\views/auth/login.blade.php ENDPATH**/ ?>