<?php $__env->startSection('title', 'Edit Skema'); ?>

<?php $__env->startSection('content'); ?>

<h1>Edit Skema</h1>

<div class="form-container">

    <h2>Form Edit Skema</h2>

    <form
        action="<?php echo e(route('skema.update', $skema)); ?>"
        method="POST"
    >

        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        

        <div class="form-group">

            <label for="nama_skema">
                Nama Skema
            </label>

            <input
                type="text"
                id="nama_skema"
                name="nama_skema"
                value="<?php echo e(old('nama_skema', $skema->nama_skema)); ?>"
                required
            >

            <?php $__errorArgs = ['nama_skema'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>


        

        <div class="form-group">

            <label for="kode_skema">
                Kode Skema
            </label>

            <input
                type="text"
                id="kode_skema"
                name="kode_skema"
                value="<?php echo e(old('kode_skema', $skema->kode_skema)); ?>"
                required
            >

            <?php $__errorArgs = ['kode_skema'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>


        

        <div class="form-group">

            <label for="deskripsi">
                Deskripsi
            </label>

            <textarea
                id="deskripsi"
                name="deskripsi"
                rows="5"
            ><?php echo e(old('deskripsi', $skema->deskripsi)); ?></textarea>

            <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>


        

        <div class="form-actions">

            <a
                href="<?php echo e(route('skema.index')); ?>"
                class="button cancel"
            >
                Batal
            </a>

            <button
                type="submit"
                class="button save"
            >
                Simpan Perubahan
            </button>

        </div>

    </form>

</div>


<style>

    .form-container {
        background-color: white;

        padding: 25px;

        border-radius: 10px;

        max-width: 700px;

        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
    }

    .form-container h2 {
        margin-top: 0;

        margin-bottom: 25px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;

        margin-bottom: 7px;

        font-weight: bold;
    }

    .form-group input,
    .form-group textarea {
        width: 100%;

        padding: 10px;

        border: 1px solid #ccc;

        border-radius: 5px;

        font-family: Arial, sans-serif;

        font-size: 14px;
    }

    .form-group textarea {
        resize: vertical;
    }

    .form-group input:focus,
    .form-group textarea:focus {
        outline: none;

        border-color: #555;
    }

    .error {
        color: #b00020;

        font-size: 13px;

        margin-top: 5px;
    }

    .form-actions {
        display: flex;

        gap: 10px;

        margin-top: 25px;
    }

    .button {
        display: inline-block;

        padding: 10px 16px;

        border: none;

        border-radius: 5px;

        text-decoration: none;

        cursor: pointer;

        font-size: 14px;
    }

    .cancel {
        background-color: #ddd;

        color: #333;
    }

    .save {
        background-color: #333;

        color: white;
    }

    .button:hover {
        opacity: 0.8;
    }

</style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\skema_sertifikasi_resky\resources\views/skema/edit.blade.php ENDPATH**/ ?>