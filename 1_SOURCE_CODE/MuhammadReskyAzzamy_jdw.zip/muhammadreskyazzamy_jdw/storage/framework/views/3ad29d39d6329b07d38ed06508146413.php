<?php $__env->startSection('title', 'Detail Skema'); ?>

<?php $__env->startSection('content'); ?>

<h1></h1>




<div class="detail-card">

    <h2>
        <?php echo e($skema->nama_skema); ?>

    </h2>

    <div class="detail-item">

        <span class="label">
            Kode Skema
        </span>

        <span>
            <?php echo e($skema->kode_skema); ?>

        </span>

    </div>


    <div class="detail-item">

        <span class="label">
            Deskripsi
        </span>

        <span>
            <?php echo e($skema->deskripsi ?: '-'); ?>

        </span>

    </div>

</div>




<div class="peserta-card">

    <h2>
        Peserta yang Mengikuti Skema
    </h2>

    <?php if($skema->pesertas->count() > 0): ?>

        <table>

            <thead>

                <tr>
                    <th>No</th>
                    <th>Nama Peserta</th>
                    <th>Email</th>
                    <th>No. HP</th>
                </tr>

            </thead>

            <tbody>

                <?php $__currentLoopData = $skema->pesertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>

                        <td>
                            <?php echo e($loop->iteration); ?>

                        </td>

                        <td>
                            <?php echo e($peserta->nama); ?>

                        </td>

                        <td>
                            <?php echo e($peserta->email); ?>

                        </td>

                        <td>
                            <?php echo e($peserta->no_hp); ?>

                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>

        </table>

    <?php else: ?>

        <p class="empty">
            Belum ada peserta yang mengikuti skema ini.
        </p>

    <?php endif; ?>

</div>




<div class="actions">

    <a
        href="<?php echo e(route('skema.index')); ?>"
        class="button back"
    >
        ← Kembali
    </a>
    <?php if(Auth::user()->role === 'admin'): ?>
    <a
        href="<?php echo e(route('skema.edit', $skema)); ?>"
        class="button edit"
    >
        Edit Skema
    </a>
    <?php endif; ?>
</div>


<style>

    .detail-card,
    .peserta-card {
        background-color: white;

        padding: 25px;

        border-radius: 10px;

        margin-bottom: 20px;

        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
    }

    .detail-card h2,
    .peserta-card h2 {
        margin-top: 0;

        margin-bottom: 20px;
    }

    .detail-item {
        display: flex;

        padding: 12px 0;

        border-bottom: 1px solid #eee;

        gap: 20px;
    }

    .detail-item:last-child {
        border-bottom: none;
    }

    .label {
        font-weight: bold;

        width: 150px;

        flex-shrink: 0;
    }

    table {
        width: 100%;

        border-collapse: collapse;
    }

    th,
    td {
        padding: 12px;

        border-bottom: 1px solid #ddd;

        text-align: left;
    }

    th {
        background-color: #333;

        color: white;
    }

    tr:hover {
        background-color: #f5f5f5;
    }

    .empty {
        color: #777;
    }

    .actions {
        display: flex;

        gap: 10px;
    }

    .button {
        display: inline-block;

        padding: 10px 15px;

        border-radius: 5px;

        text-decoration: none;

        font-size: 14px;
    }

    .back {
        background-color: #ddd;

        color: #333;
    }

    .edit {
        background-color: #333;

        color: white;
    }

    .button:hover {
        opacity: 0.8;
    }

    @media (max-width: 700px) {

        .detail-item {
            flex-direction: column;

            gap: 5px;
        }

        .label {
            width: auto;
        }

        .peserta-card {
            overflow-x: auto;
        }

    }

</style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\muhammadreskyazzamy_jdw\resources\views/skema/show.blade.php ENDPATH**/ ?>