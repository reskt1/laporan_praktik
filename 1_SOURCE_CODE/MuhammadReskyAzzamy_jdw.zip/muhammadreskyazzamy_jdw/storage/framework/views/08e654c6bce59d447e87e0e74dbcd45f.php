<?php $__env->startSection('title', 'Data Peserta'); ?>

<?php $__env->startSection('content'); ?>

<h1>Data Peserta</h1>



<?php if(session('success')): ?>

    <div class="alert-success">
        <?php echo e(session('success')); ?>

    </div>

<?php endif; ?>




<div class="page-header">

    <div>

        <h2>Daftar Peserta</h2>

        <p>
            Data peserta sertifikasi yang terdaftar.
        </p>

    </div>

    <a
        href="<?php echo e(route('peserta.create')); ?>"
        class="button"
    >
        + Tambah Peserta
    </a>

</div>




<div class="search-container">

    <form
        action="<?php echo e(route('peserta.index')); ?>"
        method="GET"
    >

        <input
            type="text"
            name="search"
            value="<?php echo e(request('search')); ?>"
            placeholder="Cari nama, email, no HP, atau skema..."
        >

        <button
            type="submit"
            class="button search-button"
        >
            Cari
        </button>

        <?php if(request('search')): ?>

            <a
                href="<?php echo e(route('peserta.index')); ?>"
                class="button reset"
            >
                Reset
            </a>

        <?php endif; ?>

    </form>

</div>




<div class="table-container">

    <table>

        <thead>

            <tr>
                <th>No</th>
                <th>NIK</th>
                <th>Nama</th>
                <th>Email</th>
                <th>No. HP</th>
                <th>Skema</th>
                <th>Aksi</th>
            </tr>

        </thead>

        <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $pesertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <tr>

                    <td>
                        <?php echo e($loop->iteration); ?>

                    </td>

                    <td>
                        <?php echo e($peserta->nik); ?>

                    </td>

                    <td>
                        <?php echo e($peserta->nama); ?>

                    </td>

                    <td>
                        <?php echo e($peserta->email); ?>

                    </td>

                    <td>
                        <?php echo e($peserta->no_hp); ?>

                    </td>

                    <td>
                        <?php echo e($peserta->skema->nama_skema ?? '-'); ?>

                    </td>

                    <td class="actions">

                        <a
                            href="<?php echo e(route('peserta.show', $peserta)); ?>"
                            class="button detail"
                        >
                            Detail
                        </a>

                        <a
                            href="<?php echo e(route('peserta.edit', $peserta)); ?>"
                            class="button edit"
                        >
                            Edit
                        </a>

                        <form
                            action="<?php echo e(route('peserta.destroy', $peserta)); ?>"
                            method="POST"
                            style="display: inline;"
                        >

                            <?php echo csrf_field(); ?>

                            <?php echo method_field('DELETE'); ?>

                            <button
                                type="submit"
                                class="button delete"
                                onclick="return confirm('Yakin ingin menghapus peserta ini?')"
                            >
                                Hapus
                            </button>

                        </form>

                    </td>

                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <tr>

                    <td
                        colspan="6"
                        class="empty"
                    >
                        <?php if(request('search')): ?>
                            Peserta dengan kata pencarian tersebut tidak ditemukan.
                        <?php else: ?>
                            Belum ada data peserta.
                        <?php endif; ?>
                    </td>

                </tr>

            <?php endif; ?>

        </tbody>

    </table>

</div>


<style>

    .alert-success {
        background-color: #d4edda;

        color: #155724;

        padding: 12px 15px;

        border-radius: 6px;

        margin-bottom: 20px;
    }

    .page-header {
        background-color: white;

        padding: 20px 25px;

        border-radius: 10px;

        margin-bottom: 20px;

        display: flex;

        justify-content: space-between;

        align-items: center;

        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
    }

    .page-header h2 {
        margin: 0 0 5px 0;
    }

    .page-header p {
        margin: 0;

        color: #666;
    }

    .search-container {
        background-color: white;

        padding: 15px 20px;

        border-radius: 10px;

        margin-bottom: 20px;

        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
    }

    .search-container form {
        display: flex;

        gap: 10px;
    }

    .search-container input {
        flex: 1;

        padding: 10px;

        border: 1px solid #ccc;

        border-radius: 5px;

        font-size: 14px;
    }

    .search-container input:focus {
        outline: none;

        border-color: #555;
    }

    .button {
        display: inline-block;

        padding: 8px 12px;

        border: none;

        border-radius: 5px;

        text-decoration: none;

        cursor: pointer;

        font-size: 14px;

        background-color: #333;

        color: white;
    }

    .button:hover {
        opacity: 0.8;
    }

    .search-button {
        background-color: #333;
    }

    .reset {
        background-color: #ddd;

        color: #333;
    }

    .detail {
        background-color: #ffa601;
    }

    .edit {
        background-color: #01ccff;
    }

    .delete {
        background-color:   #ff0101;
    }

    .table-container {
        background-color: white;

        padding: 20px;

        border-radius: 10px;

        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);

        overflow-x: auto;
    }

    table {
        width: 100%;

        border-collapse: collapse;
    }

    th,
    td {
        padding: 12px;

        border-bottom: 1px solid #ddd;

        text-align: left;
    }

    th {
       background-color: #2b5cb8;;

        color: white;
    }

    tr:hover {
        background-color: #6cdff3;
    }

    .actions {
        white-space: nowrap;
    }

    .empty {
        text-align: center;

        color: #777;

        padding: 30px;
    }

    @media (max-width: 700px) {

        .page-header {
            flex-direction: column;

            align-items: flex-start;

            gap: 15px;
        }

        .search-container form {
            flex-direction: column;
        }

    }

</style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\skema_sertifikasi_resky\resources\views/peserta/index.blade.php ENDPATH**/ ?>