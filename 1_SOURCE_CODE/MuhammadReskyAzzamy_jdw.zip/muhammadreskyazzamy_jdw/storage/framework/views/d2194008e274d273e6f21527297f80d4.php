<?php $__env->startSection('title', 'Tambah Peserta'); ?>

<?php $__env->startSection('content'); ?>

<h1></h1>

<div class="form-container">

    <h2>Form Tambah Peserta</h2>

    <form
        action="<?php echo e(route('peserta.store')); ?>"
        method="POST"
    >

        <?php echo csrf_field(); ?>

        

        <div class="form-group">

            <label for="skema_id">
                Skema Sertifikasi
            </label>

            <select
                id="skema_id"
                name="skema_id"
                required
            >

                <option value="">
                    -- Pilih Skema --
                </option>

                <?php $__currentLoopData = $skemas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skema): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option
                        value="<?php echo e($skema->id); ?>"
                        <?php echo e(old('skema_id') == $skema->id ? 'selected' : ''); ?>

                    >
                        <?php echo e($skema->nama_skema); ?>

                    </option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>

            <?php $__errorArgs = ['skema_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>

        

        <div class="form-group">

            <label for="nama">
                NIK
            </label>

            <input
                type="text"
                id="nik"
                name="nik"
                value="<?php echo e(old('nik')); ?>"
                required
            >

            <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>

        

        <div class="form-group">

            <label for="nama">
                Nama Peserta
            </label>

            <input
                type="text"
                id="nama"
                name="nama"
                value="<?php echo e(old('nama')); ?>"
                required
            >

            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>


        

        <div class="form-group">

            <label for="email">
                Email
            </label>

            <input
                type="email"
                id="email"
                name="email"
                value="<?php echo e(old('email')); ?>"
                required
            >

            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>


        

        <div class="form-group">

            <label for="no_hp">
                Nomor HP
            </label>

            <input
                type="text"
                id="no_hp"
                name="no_hp"
                value="<?php echo e(old('no_hp')); ?>"
                required
            >

            <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>


        

        <div class="form-group">

            <label for="alamat">
                Alamat
            </label>

            <textarea
                id="alamat"
                name="alamat"
                rows="5"
                required
            ><?php echo e(old('alamat')); ?></textarea>

            <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>


        

        <div class="form-actions">

            <a
                href="<?php echo e(route('peserta.index')); ?>"
                class="button cancel"
            >
                Batal
            </a>

            <button
                type="submit"
                class="button save"
            >
                Simpan
            </button>

        </div>

    </form>

</div>


<style>

    .form-container {
        background-color: white;

        padding: 25px;

        border-radius: 10px;

        max-width: 700px;

        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
    }

    .form-container h2 {
        margin-top: 0;

        margin-bottom: 25px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;

        margin-bottom: 7px;

        font-weight: bold;
    }

    .form-group input,
    .form-group select,
    .form-group textarea {
        width: 100%;

        padding: 10px;

        border: 1px solid #ccc;

        border-radius: 5px;

        font-family: Arial, sans-serif;

        font-size: 14px;
    }

    .form-group textarea {
        resize: vertical;
    }

    .form-group input:focus,
    .form-group select:focus,
    .form-group textarea:focus {
        outline: none;

        border-color: #555;
    }

    .error {
        color: #b00020;

        font-size: 13px;

        margin-top: 5px;
    }

    .form-actions {
        display: flex;

        gap: 10px;

        margin-top: 25px;
    }

    .button {
        display: inline-block;

        padding: 10px 16px;

        border: none;

        border-radius: 5px;

        text-decoration: none;

        cursor: pointer;

        font-size: 14px;
    }

    .cancel {
        background-color: #ddd;

        color: #333;
    }

    .save {
        background-color: #333;

        color: white;
    }

    .button:hover {
        opacity: 0.8;
    }

</style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\muhammadreskyazzamy_jdw\resources\views/peserta/create.blade.php ENDPATH**/ ?>